
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';

void main() { runApp(GreenHavenRO()); }

class GreenHavenRO extends StatefulWidget {
  @override _GreenHavenROState createState() => _GreenHavenROState();
}

class _GreenHavenROState extends State<GreenHavenRO> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Green Haven',
      theme: ThemeData.dark().copyWith(primaryColor: Colors.greenAccent),
      home: HomeScreen(),
    );
  }
}

class GameState {
  int day; int money; int space; List<Map<String,dynamic>> plants; Map<String,int> inventory;
  List<String> team; int heat; int halaLevel; int reputation; Map<String,int> seeds;
  GameState._(this.day,this.money,this.space,this.plants,this.inventory,this.team,this.heat,this.halaLevel,this.reputation,this.seeds);
  factory GameState.newGame() => GameState._(1,1000,10,[],{},[],10,1,10,{'Solara':5});
  Map<String,dynamic> toJson()=>{'day':day,'money':money,'space':space,'plants':plants,'inventory':inventory,'team':team,'heat':heat,'halaLevel':halaLevel,'reputation':reputation,'seeds':seeds};
  factory GameState.fromJson(Map<String,dynamic> j) => GameState._(j['day'],j['money'],j['space'],List<Map<String,dynamic>>.from(j['plants'] ?? []), Map<String,int>.from(j['inventory'] ?? {}), List<String>.from(j['team'] ?? []), j['heat'], j['halaLevel'], j['reputation'], Map<String,int>.from(j['seeds'] ?? {}));
}

final plantTypes = {
  'Solara': {'grow':2,'yield':3,'value':200,'heat':2},
  'Noctis': {'grow':3,'yield':5,'value':450,'heat':5},
  'Lunara': {'grow':4,'yield':8,'value':900,'heat':8},
  'Emberleaf': {'grow':5,'yield':12,'value':1600,'heat':12},
};

class HomeScreen extends StatefulWidget {
  @override _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  GameState state = GameState.newGame();
  bool loading = true;
  List<String> events = [];
  AudioPlayer? _musicPlayer;
  AudioCache? _audioCache;

  @override void initState(){ super.initState(); _load(); _initAudio(); }

  Future<void> _initAudio() async {
    _musicPlayer = AudioPlayer();
    _audioCache = AudioCache(prefix: 'assets/audio/');
    _musicPlayer?.setReleaseMode(ReleaseMode.loop);
    try {
      final url = await _audioCache!.load('loop_placeholder.wav');
      _musicPlayer?.play(url.path, volume: 0.25, isLocal: true);
    } catch (e) {}
  }

  Future<void> _load() async {
    SharedPreferences p = await SharedPreferences.getInstance();
    String? raw = p.getString('greenhaven_save');
    if(raw!=null){ try{ setState(()=> state = GameState.fromJson(json.decode(raw))); }catch(_){} }
    setState(()=>loading=false);
  }

  Future<void> _autosave() async { SharedPreferences p = await SharedPreferences.getInstance(); await p.setString('greenhaven_save', json.encode(state.toJson())); }

  void _addEvent(String s){ setState(()=> events.insert(0,'Zi ${state.day}: $s')); if(events.length>30) events.removeLast(); _audioCache?.play('click_placeholder.wav'); _autosave(); }

  void _plant(String type,int qty){ if(state.plants.length+qty>state.space){ _addEvent('Spațiu insuficient'); return;} int owned = state.seeds[type] ?? 0; if(owned<qty){ _addEvent('Nu ai sămânțe'); return;} for(int i=0;i<qty;i++) state.plants.add({'type':type,'plantedDay':state.day,'grow':plantTypes[type]['grow']}); state.seeds[type]=owned-qty; state.heat = min(100, state.heat + plantTypes[type]['heat'] as int); _addEvent('Ai plantat $qty x $type'); setState(()=>{}); }

  void _harvest(){ var ready = state.plants.where((p)=>(state.day - p['plantedDay']) >= p['grow']).toList(); if(ready.isEmpty){ _addEvent('Nimic de recoltat'); return;} Map<String,int> totals={}; for(var p in ready){ totals[p['type']] = (totals[p['type']] ?? 0) + plantTypes[p['type']]['yield'] as int; } state.plants.removeWhere((p)=>(state.day - p['plantedDay']) >= p['grow']); totals.forEach((t,q){ double bonus = state.team.length * 0.05; int produced = max(1, ((q * (1 + bonus))).floor()); String key = '$t Produs'; state.inventory[key] = (state.inventory[key] ?? 0) + produced; _addEvent('Recoltat $produced x $key'); }); state.heat = min(100, state.heat + 3); setState(()=>{}); }

  void _waitDay(){ double r = Random().nextDouble(); if(r<0.15){ double r2 = Random().nextDouble(); if(r2<0.25){ int amount = 1 + Random().nextInt(3); String kind = plantTypes.keys.elementAt(Random().nextInt(plantTypes.length)); int price = (plantTypes[kind]!['value']! * (0.9 + Random().nextDouble() * 0.7)).floor(); _addEvent('Oferta: $amount x $kind Produs la $price'); } else if(r2<0.6){ if(state.plants.isNotEmpty && Random().nextDouble()<0.5){ int lost = min(state.plants.length, 1 + Random().nextInt(3)); state.plants.removeRange(0,lost); _addEvent('Rivali ți-au furat $lost plante'); } else _addEvent('Complot rival eșuat'); } else { int inc = 1 + Random().nextInt(5); state.heat = min(100, state.heat + inc); _addEvent('Patrulă în zonă; heat +$inc'); } } state.heat = max(0, state.heat -1); state.day += 1; if(state.heat >=70 && Random().nextDouble() < (state.heat - 60) /50) _raid(); setState(()=>{}); }

  void _raid(){ bool success = Random().nextDouble() < (0.5 - 0.05 * state.team.length + (state.reputation - 50)/200); if(success){ int lostMoney = (state.money * (0.1 + Random().nextDouble() * 0.3)).floor(); Map<String,int> lostInv={}; if(state.inventory.isNotEmpty){ String k = state.inventory.keys.elementAt(Random().nextInt(state.inventory.keys.length)); int lostQ = min(state.inventory[k]!, 1 + Random().nextInt(max(1, state.inventory[k]! ~/ 2))); lostInv[k]=lostQ; state.inventory[k] = state.inventory[k]! - lostQ; if(state.inventory[k]==0) state.inventory.remove(k); } state.money = max(0, state.money - lostMoney); state.heat = min(100, state.heat + 10); bool jail = Random().nextDouble() < 0.4; _addEvent('Raid! Pierdut $lostMoney'); if(jail) _goToJail(); } else { _addEvent('Ai respins raidul'); state.reputation = max(0, state.reputation - 5); state.heat = max(0, state.heat - 10); } }

  void _goToJail(){ int days = 3 + Random().nextInt(6); int fine = (state.money * 0.2).floor(); _addEvent('Ai fost arestat! Cauțiune $fine'); for(int i=0;i<days;i++) state.day +=1; state.heat = max(0, state.heat -30); state.reputation = max(0, state.reputation -10); _addEvent('Ai servit zile în închisoare'); setState(()=>{}); }

  void _buySeeds(String type,int qty){ int cost = 100 + (plantTypes[type]!['value']! ~/5); int total = cost * qty; if(state.money<total){ _addEvent('Nu ai bani'); return;} state.money -= total; state.seeds[type] = (state.seeds[type] ?? 0) + qty; state.heat = min(100, state.heat + 1); _addEvent('Ai cumpărat $qty sămânțe de $type'); setState(()=>{}); }

  void _hire(String name){ int cost=150; if(state.money<cost){ _addEvent('Nu ai bani'); return;} state.money -= cost; state.team.add(name); state.heat = min(100, state.heat + 1); _addEvent('Ai angajat pe $name'); setState(()=>{}); }

  void _upgradeHala(){ int cost = 1000 * state.halaLevel; if(state.money<cost){ _addEvent('Nu ai bani'); return;} state.money -= cost; state.halaLevel +=1; state.space += 20 * state.halaLevel; state.reputation = min(100, state.reputation + 5); _addEvent('Hala upgradată'); setState(()=>{}); }

  void _sell(String item,int qty){ if((state.inventory[item] ?? 0) < qty){ _addEvent('Nu ai atâtea'); return;} String baseName = item.replaceAll(' Produs',''); int base = plantTypes[baseName]?['value'] ?? 100; double market = 0.8 + Random().nextDouble() * 0.6; int price = (base * market * (1 + (state.reputation - 50)/200)).floor(); int total = price * qty; state.inventory[item] = state.inventory[item]! - qty; if(state.inventory[item]==0) state.inventory.remove(item); state.money += total; state.heat = min(100, state.heat + (qty * 1.5).floor()); state.reputation = max(0, min(100, state.reputation + (market>1.0?5:-2))); _addEvent('Ai vândut $qty x $item pentru $total'); setState(()=>{}); }

  Widget _topBar()=> Column(crossAxisAlignment: CrossAxisAlignment.start, children: [ Text('Zi ${state.day} • Bani ${state.money} • Heat ${state.heat}%', style: TextStyle(fontSize:16)), SizedBox(height:6), Row(children: [ Chip(label: Text('Hala Lv ${state.halaLevel}')), SizedBox(width:8), Chip(label: Text('Rep ${state.reputation}')), SizedBox(width:8), Chip(label: Text('Spațiu ${state.plants.length}/${state.space}')) ]) ]);

  Widget _inventoryCard()=> Card(child: Padding(padding:EdgeInsets.all(10), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[ Text('Inventar & Sămânțe', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:6), Wrap(spacing:8, children: state.inventory.entries.map((e)=> Chip(label: Text('${e.key}: ${e.value}'))).toList()), SizedBox(height:6), Text('Sămânțe: ${state.seeds.entries.map((e) => '${e.key}:${e.value}').join('  ')}') ])));
  Widget _plantsCard()=> Card(child: Padding(padding:EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text('Plante în seră', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:6), state.plants.isEmpty? Text('Niciuna') : Column(children: state.plants.map((p){ int planted=p['plantedDay']; int grow=p['grow']; int daysLeft = max(0, grow - (state.day - planted)); return ListTile(title: Text('${p['type']} (rămân $daysLeft zile)'), subtitle: Text('Plantat ziua $planted')); }).toList()) ])));

  Widget _actions()=> Card(child: Padding(padding:EdgeInsets.all(8), child: Column(children:[ Wrap(spacing:8, runSpacing:8, children:[ ElevatedButton.icon(onPressed: _harvest, icon: Icon(Icons.agriculture), label: Text('Recoltează')), ElevatedButton.icon(onPressed: ()=> _showPlantDialog(), icon: Icon(Icons.spa), label: Text('Plantează')), ElevatedButton.icon(onPressed: ()=> _showSellDialog(), icon: Icon(Icons.sell), label: Text('Vinde')), ElevatedButton.icon(onPressed: ()=> _showBuySeedsDialog(), icon: Icon(Icons.shopping_cart), label: Text('Cumpără sămânțe')), ElevatedButton.icon(onPressed: ()=> _showHireDialog(), icon: Icon(Icons.person_add), label: Text('Angajează')), ElevatedButton.icon(onPressed: _upgradeHala, icon: Icon(Icons.home_repair_service), label: Text('Upgrade Hala')), ElevatedButton.icon(onPressed: _waitDay, icon: Icon(Icons.timer), label: Text('Așteaptă 1 zi')), ElevatedButton.icon(onPressed: _save, icon: Icon(Icons.save), label: Text('Salvează')) ]) ])));

  void _showPlantDialog(){ String selected='Solara'; int qty=1; showDialog(context: context, builder: (c)=> AlertDialog(title: Text('Plantează'), content: StatefulBuilder(builder:(c2,s){ return Column(mainAxisSize: MainAxisSize.min, children:[ DropdownButton<String>(value:selected, items: plantTypes.keys.map((k)=> DropdownMenuItem(child: Text(k), value:k)).toList(), onChanged: (v)=> s(()=> selected = v!)), Row(children:[ Text('Cant:'), SizedBox(width:8), IconButton(onPressed: ()=> s(()=> qty = max(1, qty-1)), icon: Icon(Icons.remove)), Text('$qty'), IconButton(onPressed: ()=> s(()=> qty = qty+1), icon: Icon(Icons.add)), ]) ]);} ), actions: [ TextButton(onPressed: ()=> Navigator.of(context).pop(), child: Text('Anulează')), ElevatedButton(onPressed: (){ _plant(selected, qty); Navigator.of(context).pop(); }, child: Text('Plantă')) ])); }

  void _showSellDialog(){ if(state.inventory.isEmpty){ _addEvent('Nu ai nimic de vândut'); return;} String selected = state.inventory.keys.first; int qty=1; showDialog(context: context, builder:(c)=> AlertDialog(title: Text('Vinde'), content: StatefulBuilder(builder:(c2,s){ return Column(mainAxisSize: MainAxisSize.min, children:[ DropdownButton<String>(value:selected, items: state.inventory.keys.map((k)=> DropdownMenuItem(child: Text(k), value:k)).toList(), onChanged: (v)=> s(()=> selected = v!)), Row(children:[ Text('Cant:'), SizedBox(width:8), IconButton(onPressed: ()=> s(()=> qty = max(1, qty-1)), icon: Icon(Icons.remove)), Text('$qty'), IconButton(onPressed: ()=> s(()=> qty = qty+1), icon: Icon(Icons.add)), ]) ]);} ), actions: [ TextButton(onPressed: ()=> Navigator.of(context).pop(), child: Text('Anulează')), ElevatedButton(onPressed: (){ _sell(selected, qty); Navigator.of(context).pop(); }, child: Text('Vinde')) ])); }

  void _showBuySeedsDialog(){ String selected = plantTypes.keys.first; int qty=1; showDialog(context: context, builder:(c)=> AlertDialog(title: Text('Cumpără sămânțe'), content: StatefulBuilder(builder:(c2,s){ return Column(mainAxisSize: MainAxisSize.min, children:[ DropdownButton<String>(value:selected, items: plantTypes.keys.map((k)=> DropdownMenuItem(child: Text(k), value:k)).toList(), onChanged: (v)=> s(()=> selected = v!)), Row(children:[ Text('Cant:'), SizedBox(width:8), IconButton(onPressed: ()=> s(()=> qty = max(1, qty-1)), icon: Icon(Icons.remove)), Text('$qty'), IconButton(onPressed: ()=> s(()=> qty = qty+1), icon: Icon(Icons.add)), ]) ]);} ), actions: [ TextButton(onPressed: ()=> Navigator.of(context).pop(), child: Text('Anulează')), ElevatedButton(onPressed: (){ _buySeeds(selected, qty); Navigator.of(context).pop(); }, child: Text('Cumpără')) ])); }

  void _showHireDialog(){ String name='Ion'; showDialog(context: context, builder:(c)=> AlertDialog(title: Text('Angajează'), content: TextField(decoration: InputDecoration(labelText: 'Nume angajat'), onChanged: (v)=> name=v), actions:[ TextButton(onPressed: ()=> Navigator.of(context).pop(), child: Text('Anulează')), ElevatedButton(onPressed: (){ if(name.trim().isNotEmpty) _hire(name.trim()); Navigator.of(context).pop(); }, child: Text('Angajează')) ])); }

  void _save(){ _autosave(); _addEvent('Joc salvat'); }

  Widget _buildEvents()=> Card(child: Padding(padding:EdgeInsets.all(10), child: Column(children:[ Text('Evenimente recente', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:6), Container(height:160, child: ListView.builder(itemCount: events.length, itemBuilder:(c,i)=> ListTile(dense:true,title: Text(events[i])))) ])));

  @override Widget build(BuildContext context){
    if(loading) return Scaffold(body: Center(child:CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Row(children:[ Image.asset('assets/images/logo.png', height:36), SizedBox(width:8), Text('Green Haven')])),
      body: SingleChildScrollView(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _topBar(), SizedBox(height:10),
        _inventoryCard(), SizedBox(height:8),
        _plantsCard(), SizedBox(height:8),
        _actions(), SizedBox(height:8),
        _buildEvents()
      ]))
    );
  }
}
