
Green Haven - Romanian test build
================================

Acesta este un pachet sursă Flutter pregătit pentru upload în GitHub și build în CodeMagic.

Cum încarci pachetul pe GitHub (folosind Safari pe iPhone):
1. Descarcă acest ZIP pe telefon.
2. Deschide Safari și accesează https://github.com
3. Autentifică-te și intră în repository-ul tău.
4. Apasă pe 'Add file' -> 'Upload files'.
5. Selectează fișierul ZIP din aplicația Files și commit.

Cum schimbi melodia placeholder cu 'Stay Alert' (Bensound):
1. Descarcă 'Stay Alert' de pe Bensound.
2. Pune fișierul în assets/audio/ și numește-l stay_alert.mp3.
3. Editează lib/main.dart pentru a încărca 'stay_alert.mp3' în loc de loop_placeholder.wav.
4. Actualizează pubspec.yaml și Rulează build în CodeMagic.

Build iOS pe CodeMagic (rezumat):
1. Conectează-ți contul GitHub în CodeMagic și adaugă repo.
2. Configurează build pentru iOS.
3. La 'Apple Developer' adaugă Apple ID pentru semnare.
4. Rulează build și descarcă .ipa (TestFlight).

Notă: fișierele audio din pachet sunt 'placeholder'. Trebuie să înlocuiești cu fișierele licențiate.
